<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['id_usuario']) || strtolower(trim($_SESSION['usuario_rol'])) !== 'alumno') {

    echo "<script>window.location.href = '../../../php/endpoints/login.php';</script>";
    exit();
}
?>
<div class="alert alert-info border-0 shadow-sm rounded-3">
    <i class="bi bi-info-circle-fill me-2"></i><strong>Proceso de Inscripción:</strong> Selecciona el ETS que deseas presentar. Recuerda que después de inscribirte deberás subir tu comprobante de pago en el Inicio para que el administrador valide tu lugar.
</div>

<div class="input-group mb-4 shadow-sm">
    <span class="input-group-text bg-white border-end-0 text-muted"><i class="bi bi-search"></i></span>
    <input type="text" class="form-control border-start-0 ps-0" placeholder="Buscar por materia, academia o profesor...">
    <button class="btn btn-primary fw-semibold px-4" type="button">Filtrar</button>
</div>

<div class="card shadow-sm border-0 rounded-3">
    <div class="card-header bg-white pt-4 pb-2 border-bottom-0">
        <h5 class="card-title fw-bold mb-0 text-dark">Exámenes de ETS Disponibles</h5>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4">Materia</th>
                        <th>Fecha y Hora</th>
                        <th>Profesor / Sinodal</th>
                        <th>Salón / Edificio</th>
                        <th>Cupo Disp.</th>
                        <th class="pe-4 text-end">Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="ps-4">
                            <span class="fw-semibold text-dark d-block">Estructuras de Datos</span>
                            <small class="text-muted">Academia de Computación</small>
                        </td>
                        <td>
                            <span class="d-block fw-medium"><i class="bi bi-calendar3 me-2 text-muted"></i>12/06/2026</span>
                            <small class="text-muted ms-4">10:00 AM</small>
                        </td>
                        <td>Dr. Alberto Martínez</td>
                        <td>
                            <span class="text-primary fw-medium">Aula 2104</span>
                            <small class="text-muted d-block">Edificio 2</small>
                        </td>
                        <td>
                            <span class="badge bg-success bg-opacity-10 text-success rounded-pill px-2.5 py-1.5">25 lugares</span>
                        </td>
                        <td class="pe-4 text-end">
                            <button class="btn btn-success btn-sm shadow-sm px-3 rounded-pill fw-medium">
                                <i class="bi bi-pencil-square me-1"></i> Inscribirme
                            </button>
                        </td>
                    </tr>
                    <tr>
                        <td class="ps-4">
                            <span class="fw-semibold text-dark d-block">Cálculo Aplicado</span>
                            <small class="text-muted">Academia de Ciencias Básicas</small>
                        </td>
                        <td>
                            <span class="d-block fw-medium"><i class="bi bi-calendar3 me-2 text-muted"></i>15/06/2026</span>
                            <small class="text-muted ms-4">12:00 PM</small>
                        </td>
                        <td>M. en C. Elena Ríos</td>
                        <td>
                            <span class="text-primary fw-medium">Laboratorio 3</span>
                            <small class="text-muted d-block">Edificio 3</small>
                        </td>
                        <td>
                            <span class="badge bg-success bg-opacity-10 text-success rounded-pill px-2.5 py-1.5">12 lugares</span>
                        </td>
                        <td class="pe-4 text-end">
                            <button class="btn btn-success btn-sm shadow-sm px-3 rounded-pill fw-medium">
                                <i class="bi bi-pencil-square me-1"></i> Inscribirme
                            </button>
                        </td>
                    </tr>
                    <tr>
                        <td class="ps-4">
                            <span class="fw-semibold text-dark d-block">Programación Orientada a Objetos</span>
                            <small class="text-muted">Academia de Computación</small>
                        </td>
                        <td>
                            <span class="d-block fw-medium"><i class="bi bi-calendar3 me-2 text-muted"></i>18/06/2026</span>
                            <small class="text-muted ms-4">08:00 AM</small>
                        </td>
                        <td>Ing. Jorge Chávez</td>
                        <td>
                            <span class="text-primary fw-medium">Aula 1201</span>
                            <small class="text-muted d-block">Edificio 1</small>
                        </td>
                        <td>
                            <span class="badge bg-danger bg-opacity-10 text-danger rounded-pill px-2.5 py-1.5">Sin cupo</span>
                        </td>
                        <td class="pe-4 text-end">
                            <button class="btn btn-secondary btn-sm px-3 rounded-pill fw-medium" disabled>
                                Agotado
                            </button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>