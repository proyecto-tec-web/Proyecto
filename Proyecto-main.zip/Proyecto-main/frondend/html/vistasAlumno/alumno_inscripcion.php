<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['id_usuario']) || strtolower(trim($_SESSION['usuario_rol'])) !== 'alumno') {

    echo "<script>window.location.href = '../../../php/endpoints/login.php';</script>";
    exit();
}
?>
<div class="container-fluid p-0">
    

    <div class="me-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" class="bi bi-info-circle-fill text-info" viewBox="0 0 16 16">
                <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zm.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1A1.125 1.125 0 1 1 0-2.25 1.125 1.125 0 0 1 0 2.25z"/>
            </svg>
        </div>
        <div style="font-size: 0.95rem;">
            <strong>Proceso de Inscripción:</strong> Selecciona el ETS que deseas presentar de la lista de materias ofertadas.
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-3 mb-4">
        <div class="card-body p-3">
            <div class="row g-2 align-items-center">
                <div class="col">
                    <input type="text" class="form-control" placeholder="Buscar por materia o profesor...">
                </div>
                <div class="col-auto">
                    <button type="button" class="btn btn-primary px-4 fw-semibold">Filtrar</button>
                </div>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-3">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light text-secondary">
                    <tr>
                        <th class="ps-4 py-3">Materia</th>
                        <th class="py-3">Fecha y Hora</th>
                        <th class="py-3">Profesor / Sinodal</th>
                        <th class="py-3">Salón</th>
                        <th class="py-3">Cupo</th>
                        <th class="pe-4 text-center py-3">Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="ps-4 fw-bold">Estructuras de Datos</td>
                        <td>12/06/2026 - 10:00 AM</td>
                        <td>Dr. Alberto Martínez</td>
                        <td><a href="#" class="text-decoration-none">Aula 2104</a></td>
                        <td><span class="badge bg-success-subtle text-success">25 disp.</span></td>
                        <td class="pe-4 text-center">
                            <button class="btn btn-success btn-sm rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#modalConfirmar">Inscribirme</button>
                        </td>
                    </tr>
                    <tr>
                        <td class="ps-4 fw-bold">Cálculo Aplicado</td>
                        <td>15/06/2026 - 12:00 PM</td>
                        <td>M. en C. Elena Ríos</td>
                        <td><a href="#" class="text-decoration-none">Laboratorio 3</a></td>
                        <td><span class="badge bg-success-subtle text-success">12 disp.</span></td>
                        <td class="pe-4 text-center">
                            <button class="btn btn-success btn-sm rounded-pill px-3">Inscribirme</button>
                        </td>
                    </tr>
                    <tr>
                        <td class="ps-4 fw-bold">Sistemas Operativos</td>
                        <td>19/06/2026 - 02:00 PM</td>
                        <td>Ing. Juan Carlos Domínguez</td>
                        <td><a href="#" class="text-decoration-none">Aula 3201</a></td>
                        <td><span class="badge bg-danger-subtle text-danger">Lleno</span></td>
                        <td class="pe-4 text-center">
                            <button class="btn btn-secondary btn-sm rounded-pill px-3" disabled>Agotado</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>