<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['id_usuario']) || (strtolower(trim($_SESSION['usuario_rol'])) !== 'admin' )) {
    echo json_encode(["status" => "error", "message" => "Acceso denegado."]);
    exit();
}
if (!isset($conexion) || !($conexion instanceof PDO)) {
    echo json_encode(["status" => "error", "message" => "No hay conexión a la base de datos."]);
    exit;
}

$datos = json_decode(file_get_contents("php://input"), true);
if ($datos) {
    try {
        $stmt_check = $conexion->prepare("SELECT id_usuario FROM usuario WHERE correo = ?");
        $stmt_check->execute([$datos['correo']]);
        if ($stmt_check->rowCount() > 0) {
            echo json_encode(["status" => "error", "message" => "Este correo ya está registrado."]);
            exit();
        }

        $password_hash = password_hash($datos['password'], PASSWORD_DEFAULT);
        
        $sql = "INSERT INTO usuario (correo, contrasena_hash, rol) VALUES (?, ?, ?)";
        $stmt = $conexion->prepare($sql);
        $stmt->execute([$datos['correo'], $password_hash, $datos['rol']]);
        
        echo json_encode(["status" => "success"]);
    } catch (PDOException $e) {
        echo json_encode(["status" => "error", "message" => $e->getMessage()]);
    }
}
$conexion = null;
?>